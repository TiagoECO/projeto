let menu = document.getElementById('menu')  
let conteudo = document.getElementById('conteudo') 
let teste = false 


function abrirMenu(){
    if(!teste){
        menu.style.width = '250px';
        conteudo.style.marginLeft = '250px';
        teste = true;
    }else{
        menu.style.width = '0px';
        conteudo.style.marginLeft = '0px';
        teste = false;        
    }

}
const data = Array.from({ length: 100 })
    .map((_, i) => `Item ${(i + 1)}`)
//map usa uma função pra cada elemento, o primeiro elemento n inporta por isso _, mas o segundo é um index

// ======================================================================
let perPage = 5
const state = {
    page: 1,
    perPage,
    totalPage: Math.ceil(data.length / perPage)
}

const html = {
    get(element){
        return document.querySelector(element)
    }
}

const controls = {
    next() {
        state.page++

        const lastPage = state.page > state.totalPage
        if(lastPage) {
            state.page--
        }
    },
    prev() {
        state.page--

        if(state.page < 1){
            state.page++
        }
    },
    goTo(page) {
        if (page < 1){
            page = 1
        }

        state.page = page

        if (page > state.totalPage){
            state.page = state.totalPage
        }
    },
    createListeners(){
        html.get('.first').addEventListener('click', () => {
            controls.goTo(1)
            update()
        })
        html.get('.last').addEventListener('click', () => {
            controls.goTo(state.totalPage)
            update()
        })
        html.get('.next').addEventListener('click', () => {
            controls.next()
            update()
        })
        html.get('.prev').addEventListener('click', () => {
            controls.prev()
            update()
        })
    }
}

const list = {
    create (item) {
        console.log(item)
    },
    update() {
        
    }
}
function update(){
    console.log(state.page)
}
function init (){
    list.update()
    controls.createListeners()
}

init ()
console.log(state.page)
controls.next()
console.log(state.page)
controls.prev()
console.log(state.page)


